﻿using IACryptOfTheNecroDancer;

IA ia = new IA();
ia.Start();